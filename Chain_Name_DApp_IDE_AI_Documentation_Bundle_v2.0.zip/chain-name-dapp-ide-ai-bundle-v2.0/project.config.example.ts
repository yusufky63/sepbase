export const projectConfig = {
  brand: {
    name: 'Chain Name',
    shortName: 'Chain Name',
    suffix: 'example',
    motto: 'Name your place onchain.',
    description: 'A readable identity on Base Sepolia.',
    theme: 'contrast' as const,
    accent: '#0000ff',
    logo: '/brand/logo.svg',
    mark: '/brand/mark.svg',
    favicon: '/brand/favicon.svg',
  },

  collection: {
    name: 'Chain Name',
    symbol: 'CNAME',
  },

  chain: {
    id: 84532,
    name: 'Base Sepolia',
    testnet: true,
    requiredConfirmations: 1,
    rpcUrl: process.env.NEXT_PUBLIC_RPC_URL!,
    explorerUrl: 'https://sepolia-explorer.base.org',
    nativeCurrency: {
      name: 'Ether',
      symbol: 'ETH',
      decimals: 18,
    },
  },

  settlement: {
    kind: 'native' as const,
    tokenAddress: null,
    name: 'Ether',
    symbol: 'ETH',
    decimals: 18,
  },

  names: {
    minLength: 3,
    maxLength: 32,
    allowedYears: [1, 2, 3, 4, 5] as const,
    gracePeriodDays: 30,
  },

  pricing: {
    annual: '0.0005',
    referenceFiat: null,
  },

  referrals: {
    rewardBps: 1000,
    attributionDays: 30,
  },

  marketplace: {
    feeBps: 0,
    listingsPerPage: 24,
  },

  integration: {
    docsPath: '/developers',
    metadataPath: '/api/metadata/',
    nameApiPath: '/api/name/{label}',
    resolveApiPath: '/api/resolve/{label}',
    reverseApiPath: '/api/reverse/{address}',
    wellKnownPath: '/.well-known/chain-name-service.json',
    marketApiPath: '/api/market',
    openApiPath: '/api/openapi.json',
  },

  links: {
    website: '',
    x: '',
    discord: '',
  },
} as const;
