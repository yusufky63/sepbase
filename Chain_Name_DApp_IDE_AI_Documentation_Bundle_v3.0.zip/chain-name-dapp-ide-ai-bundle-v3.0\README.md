# SEPBASE

SEPBASE is a standalone, single-chain onchain name registry. The first profile targets Base Sepolia and registers names such as `alice.sepbase` for a configured yearly settlement price.

## Product profile

- Network: Base Sepolia (`84532`)
- Settlement: native ETH
- Standard annual registration (4-32 characters): `0.0005 ETH`
- Short-name annual tiers (1/2/3 characters): `0.05 / 0.0125 / 0.0025 ETH`
- Referral reward: `10%`
- Marketplace fee: `0%`
- Contract: one non-upgradeable `ChainNameService.sol`, version `2.0.0`
- Base Sepolia deployment: [`0xe000de3efe798Aa4F834fd952Bef35BAE1B16945`](https://sepolia.basescan.org/address/0xe000de3efe798aa4f834fd952bef35bae1b16945#code)
- Design system: Modular Typography

SEPBASE is an independent testnet project. It is not an official Base product or naming service.

## Local development

Requirements: Node.js 22+, pnpm 11+, and Foundry 1.7+.

```bash
pnpm install
pnpm project:validate
pnpm contracts:build
pnpm contracts:test
pnpm dev
```

The web app runs at `http://localhost:3000` and reads the verified Base Sepolia deployment through the generated manifest. Clone profiles without a deployment still fail closed and mark chain-dependent actions as unavailable.

The home page includes a live registry summary for onchain name objects, registration availability, marketplace availability, and payment health. It reuses the global protocol-health Multicall cache and does not add polling or another RPC round trip.

The gated `/admin` workspace exposes live health, settlement statistics, contract events, and owner controls. The live owner and pending owner are admitted automatically; additional read-only viewers come from the central `admin.viewerAddresses` project config or `NEXT_PUBLIC_ADMIN_ADDRESSES`. Viewer gating hides the operational UI but does not make public blockchain data confidential. Contract writes still require the live owner wallet.

With a funded Base Sepolia deployment account configured in the ignored `.env`, the release smoke covers registration, renewal, profile/primary, referrals, marketplace settlement, claims, treasury withdrawal, and solvency:

```bash
pnpm deployment:check
pnpm smoke:base-sepolia
```

The smoke creates uniquely named test registrations and spends testnet settlement/gas funds. Temporary buyer and referrer keys are generated only in memory and their remaining gas is swept back on exit.

For hosted API reads, configure a server-only `RPC_URL` with an authenticated provider endpoint. Keep `NEXT_PUBLIC_RPC_URL` browser-safe because it is published in the manifest and client bundle. Before a public release, run:

```bash
pnpm release:check
```

This gate requires the final HTTPS origin, a separate server RPC, WalletConnect configuration, a deployed contract, and a metadata base URI matching the final origin.

## Required checks

```bash
forge fmt --check --root contracts
forge build --root contracts
forge build --sizes --root contracts
forge test -vvv --root contracts
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

See `PROJECT_SPEC.md` for the canonical product contract, `INTEGRATION_GUIDE.md` for consumer integration requirements, `docs/DEPLOYMENT.md` for deployment operations, and `docs/PRODUCTION_READINESS.md` for the release gate and prioritized follow-up report.
